//
//  XLSimpleFormFieldDelegate.h
//  XLSimpleForm
//
//  Created by Dev Floater 17  on 2012-12-04.
//  Copyright (c) 2012 XtremeLabs. All rights reserved.
//

#import <Foundation/Foundation.h>

@class XLSimpleFormField;
@protocol XLSimpleFormField;

/**
 Provides field updates to a desired object. Primarily used for validation.
 */
@protocol XLSimpleFormFieldDelegate

@optional
/// @name data validation and notification

/// used for validation, if YES is returned the field will be updated, if NO it will not
- (BOOL)shouldUpdateValue:(NSObject *)value forField:(NSObject <XLSimpleFormField> *)field;
///.
- (void)willUpdateValue:(NSObject *)value forField:(NSObject <XLSimpleFormField> *)field;
///.
- (void)didUpdateValue:(NSObject *)value forField:(NSObject <XLSimpleFormField> *)field;

@optional

- (void)didUpdateStateforField:(NSObject <XLSimpleFormField> *)field;

//- (void)firstResponderDidMoveToField:(NSObject <XLSimpleFormField> *)field;
//- (void)firstResponderDidResignFromField:(NSObject <XLSimpleFormField> *)field;
@end
