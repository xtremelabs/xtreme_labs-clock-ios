//
//  XLSimpleFormSelectionField.h
//  XLSimpleForm
//
//  Created by DX 116 on 2012-11-26.
//  Copyright (c) 2012 XtremeLabs. All rights reserved.
//

#import "XLSimpleFormField.h"

/// a simple form field extended to provide a selection list and a UIPickerView control
@class XLSimpleFormSelectionFieldSelectorView;

@interface XLSimpleFormSelectionField : XLSimpleFormField <UIPickerViewDataSource, UIPickerViewDelegate>

/// the array of selectable options
@property (strong, nonatomic) NSArray *selectionOptions;

/// the XLSimpleFormSelectionFieldSelectorView used to display the selection
@property (weak, nonatomic) XLSimpleFormSelectionFieldSelectorView *selectorView;

/// whether or not the field returns (and accepts) indexes or options (ie. 2 vs. "Ontario")
@property (nonatomic) BOOL returnsIndexSet;

@property (strong, nonatomic) NSString *componentJoiner;

@property (nonatomic) BOOL updateOnScroll;

- (void)updateSelectorView;

@end
