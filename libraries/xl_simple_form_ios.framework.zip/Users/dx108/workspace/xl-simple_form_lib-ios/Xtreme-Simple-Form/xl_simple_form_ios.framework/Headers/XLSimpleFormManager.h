//
//  XLSimpleFormManager.h
//  XLSimpleForm
//
//  Created by Dev Floater 17  on 2012-12-12.
//  Copyright (c) 2012 XtremeLabs. All rights reserved.
//

#import <Foundation/Foundation.h>
#import <UIKit/UIKit.h>

@class XLSimpleForm, XLSimpleFormField;
@protocol XLSimpleForm, XLSimpleFormField, XLSimpleFormFieldDelegate;

/**
 
 */
@protocol XLSimpleFormManager

/// the form being managed
@property (weak, nonatomic) IBOutlet UIView <XLSimpleForm> *form;

/// the object that the form is populating. If none is provided, an NSDictionary will be lazy loaded and populated.
@property (strong, nonatomic) IBOutlet NSObject *dataObject;

/// field insertion
- (void)addField:(XLSimpleFormField *)field;
- (void)addFields:(NSArray *)fields;

// field removal
- (void) removeFieldForKeyPath:(NSString*)keyPath;

/// data retrieval
- (NSObject *)retrieveFormData;

/// field access
- (NSUInteger)fieldCount;
- (XLSimpleFormField *)fieldAtIndex:(NSUInteger)fieldIndex;
- (NSArray *)fieldsAtIndexes:(NSIndexSet *)fieldIndexes;
- (XLSimpleFormField *)fieldForKeyPath:(NSString *)keyPath;

/// responder callbacks.
- (XLSimpleFormField *)nextResponderForField:(UIControl <XLSimpleFormField> *)field;
- (XLSimpleFormField *)previousResponderForField:(UIControl <XLSimpleFormField> *)field;


@end

/**
 A default implementation of the XLSimpleFormManager protocol. Can often be used as is.
 */
@interface XLSimpleFormManager : NSObject <XLSimpleFormManager>

- (IBAction)outputFormData;


/// if the defeault field delegate is set, any fields that do not specify a delegate will use this one.
@property (weak, nonatomic) IBOutlet NSObject <XLSimpleFormFieldDelegate> *defaultFieldDelegate;

@end
