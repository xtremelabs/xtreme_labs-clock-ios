//
//  XLSimpleFormTextField.h
//  XLSimpleForm
//
//  Created by DX 116 on 2012-11-26.
//  Copyright (c) 2012 XtremeLabs. All rights reserved.
//

#import "XLSimpleFormField.h"

/// A simple form field that is extended to provide a textfield.
@interface XLSimpleFormTextField : XLSimpleFormField <UITextFieldDelegate>

/// The nested textfield within the form field
@property (weak, nonatomic) UITextField *textField;

/// Called by the initializer to create the textfield, should be overridden to perform custom styling.
- (UITextField *)getTextField;

@end
