//
//  XLSimpleFormDelegate.h
//  XLSimpleForm
//
//  Created by Dev Floater 17  on 2012-12-03.
//  Copyright (c) 2012 XtremeLabs. All rights reserved.
//

#import <Foundation/Foundation.h>

@class XLSimpleFormField;
@protocol XLSimpleFormField;

/** Provides responder callbacks
 
 */
@protocol XLSimpleFormDelegate

///responder callbacks
- (void)firstResponderWillMoveToField:(UIControl <XLSimpleFormField> *)field;
- (void)firstResponderDidMoveToField:(UIControl <XLSimpleFormField> *)field;

@end
