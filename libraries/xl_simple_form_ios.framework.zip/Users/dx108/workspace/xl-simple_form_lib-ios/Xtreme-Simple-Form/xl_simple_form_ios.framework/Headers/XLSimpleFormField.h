//
//  XLSimpleFormField.h
//  XLSimpleForm
//
//  Created by DX 116 on 2012-11-26.
//  Copyright (c) 2012 XtremeLabs. All rights reserved.
//

#import <UIKit/UIKit.h>
#import "XLSimpleFormFieldDelegate.h"
#import "XLSimpleFormDelegate.h"

@class XLSimpleForm;
@protocol XLSimpleForm;

typedef enum {
    XLSimpleFormFieldClearanceBoth = 0,
    XLSimpleFormFieldClearanceLeft = 1,
    XLSimpleFormFieldClearanceRight = 2,
    XLSimpleFormFieldClearanceNone = 3,
} XLSimpleFormFieldClearance;

/** The protocol that all fields must implement to work with the module.
 
 */
@protocol XLSimpleFormField

@required

/// The object that the form will populate (using key value coding)
@property (nonatomic, weak) NSObject *dataSource;

/// The backing property for the value that will be set in the data source
@property (nonatomic, weak) NSObject *fieldValue;

/// The form that the field is a member of
@property (nonatomic, weak) NSObject <XLSimpleForm> *form;

/// @name form flow
/// abstracts firstResponder to ensure that the form controls can be kept in sync.
- (void)makeFieldActive;

///@name data outlets
/// Called to update the dataSource
- (void)updateDataSourceFromField;
/// Called to update the field from the dataSource
- (void)updateFieldFromDataSource;

@optional

/// If provided, the relative size is used to perform an automatic layout of the form.
@property (nonatomic) CGSize relativeSize;
/** Used in conjunction with relative size to determine auto layout.
 A clearance of left means that no fields should appear (on the row) to the left of this... start a new line
 A clearance of right means that this should be the last field in the row
 A clearance of none means that fields can appear on both sides of this one
 A clearance of both (the default) means that this field must appear on a row of it's own.
 */
@property (nonatomic) XLSimpleFormFieldClearance fieldClearance;

///The keyPath that this field is linked to on the dataSource object.
@property (nonatomic, strong) NSString *keyPath;

@property (nonatomic, weak) NSObject <XLSimpleFormFieldDelegate> *delegate;


/// @name field state control

/// Redeclaration of the state vairable to support custom states.
@property (nonatomic, readwrite) UIControlState state;

/// Called whenever state is changed, this should be used to set things like error styles
- (void)didUpdateState;
- (void)setApplicationState:(UIControlState)applicationState;
- (void)addApplicationStateMask:(UIControlState)applicationState;
- (void)removeApplicationStateMask:(UIControlState)applicationState;
- (BOOL)inApplicationState:(UIControlState)applicationState;

@end

/** A default implementation of the XLSimpleForm protocol.
 
 */
@interface XLSimpleFormField : UIControl <XLSimpleFormField>
/// @name initialization

- (id)initWithRelativeSize:(CGSize)relativeSize fieldClearance:(XLSimpleFormFieldClearance)fieldClearance;
/// Designated initializer
- (id)initWithKeyPath:(NSString *)keyPath relativeSize:(CGSize)relativeSize fieldClearance:(XLSimpleFormFieldClearance)fieldClearance;
/// Called at the end of the initializer to allow subclasses to perform additional configuration
- (void)configureFormField;

@property (nonatomic, assign) BOOL clearsErrorStateOnActive;

@end
