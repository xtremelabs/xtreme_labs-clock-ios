//
//  XLSimpleFormSelectionFieldSelectorView.h
//  XLSimpleForm
//
//  Created by DX 116 on 2012-11-27.
//  Copyright (c) 2012 XtremeLabs. All rights reserved.
//

#import <UIKit/UIKit.h>

/// the view used by XLSimpleFormSelectionField
@interface XLSimpleFormSelectionFieldSelectorView : UIView

/// the UILabel that displays the selected option
@property (weak, nonatomic) UILabel *selectionLabel;

/// the imageview for the disclosure (selection) indicator. If unset a default is created.
@property (weak, nonatomic) UIImageView *disclosureIndicator;

@end
