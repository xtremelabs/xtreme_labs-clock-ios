//
//  XLSimpleFormInputAccessoryView.h
//  XLSimpleForm
//
//  Created by DX 116 on 2012-11-27.
//  Copyright (c) 2012 XtremeLabs. All rights reserved.
//

#import <UIKit/UIKit.h>

typedef enum {
    XLFormToolbar_PrevNextValue_Prev = 0,
    XLFormToolbar_PrevNextValue_Next = 1
} XLFormToolbar_PrevNextValue;


@interface XLSimpleFormInputAccessoryView : UIToolbar

@property (nonatomic, strong) UISegmentedControl *prevNextControl;
@property (nonatomic, strong) UIBarButtonItem *doneButton;

+ (XLSimpleFormInputAccessoryView *) createToolbar;

@end
