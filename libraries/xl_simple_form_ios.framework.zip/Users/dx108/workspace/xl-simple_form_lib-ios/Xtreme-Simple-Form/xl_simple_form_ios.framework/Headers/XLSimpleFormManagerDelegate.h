//
//  XLSimpleFormManagerDelegate.h
//  xl_simple_form_ios
//
//  Created by Dev Floater 17  on 2012-12-14.
//  Copyright (c) 2012 Xtremelabs. All rights reserved.
//

#import <Foundation/Foundation.h>

/** Provides form management related callbacks.
 
 */
@protocol XLSimpleFormManagerDelegate <NSObject>

/// field insertion callbacks.
- (void)managerDidChangeFormFields;

@end
