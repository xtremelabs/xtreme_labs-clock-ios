//
//  XLSimpleForm.h
//  XLSimpleForm
//
//  Created by DX 116 on 2012-11-26.
//  Copyright (c) 2012 XtremeLabs. All rights reserved.
//

#import <UIKit/UIKit.h>
#import "XLSimpleFormDelegate.h"
#import "XLSimpleFormManager.h"
#import "XLSimpleFormFieldDelegate.h"
#import "XLSimpleFormManagerDelegate.h"

static const UIControlState XLSimpleFormStateError = UIControlStateApplication|(1 << 0);
static const UIControlState XLSimpleFormStateActive = UIControlStateApplication|(1 << 1);
static const UIControlState XLSimpleFormStateDisabled = UIControlStateApplication|(1 << 2);

@class XLSimpleFormField;
@protocol XLSimpleFormField;

/** The protocol that any form must implement to be used with the module.
 
 */
@protocol XLSimpleForm

@property (weak, nonatomic) IBOutlet NSObject <XLSimpleFormDelegate> *delegate;
/// if a custom manager is not provided, a standard (XLSimpleFormManager) will be lazy loaded.
@property (strong, nonatomic) IBOutlet XLSimpleFormManager *manager;

/// if a custom accessoryview is not provided a standard (XLSimpleFormInputAccessoryView) will be lazy loaded.
- (UIView *)inputAccessoryViewForField:(UIControl <XLSimpleFormField> *)field;
/// called just before the responder moves to a new field
- (void)firstResponderWillMoveToField:(XLSimpleFormField *)field;
/// called just after the responder is moved to a new field.
- (void)firstResponderDidMoveToField:(XLSimpleFormField *)field;
/// resign active field
- (void)resignActiveField;
@end

/** A default implementation of the XLSimpleForm protocol.
 
 */
@interface XLSimpleForm : UIView <XLSimpleForm, XLSimpleFormManagerDelegate>

/// If populated (by a nib) these fields will be added to the form
@property (strong, nonatomic) IBOutletCollection(UIControl <XLSimpleFormField> *) NSArray *fieldOutlets;

/// Used for auto layout, multiplied by the relative size of fields to determine their frame.
@property (nonatomic) CGSize defaultCellSize;

@property (nonatomic, weak) UIScrollView *containingScrollView;

/// used to instruct a form to re-layout including redoing the autolayout
- (void)setNeedsAutoLayout;

- (void)addApplicationStateMask:(UIControlState)controlState forKeyPaths:(NSArray *)keyPaths;
- (void)removeApplicationStateMask:(UIControlState)controlState forKeyPaths:(NSArray *)keyPaths;
- (void)setApplicationState:(UIControlState)controlState forKeyPaths:(NSArray *)keyPaths;

- (void)addApplicationStateMask:(UIControlState)controlState forKeyPath:(NSString *)keyPath;
- (void)addApplicationStateMask:(UIControlState)controlState forFieldIndex:(NSUInteger)fieldIndex;

- (void)removeApplicationStateMask:(UIControlState)controlState forKeyPath:(NSString *)keyPath;
- (void)removeApplicationStateMask:(UIControlState)controlState forFieldIndex:(NSUInteger)fieldIndex;

- (void)setApplicationState:(UIControlState)controlState forKeyPath:(NSString *)keyPath;
- (void)setApplicationState:(UIControlState)controlState forFieldIndex:(NSUInteger)fieldIndex;

@property (nonatomic, strong) UIView *inputAccessoryView;

@end
